#!/usr/bin/env bash
cd env
sudo pip install -e .
sudo pip install baselines